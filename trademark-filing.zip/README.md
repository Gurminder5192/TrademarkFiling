# Trademark Filing Website

This is a full-stack trademark filing platform built with React (frontend) and Node.js/Express (backend).